--------------------------------------------
http://www.androidicons.com/
--------------------------------------------

THANK YOU for downloading the Androidicons Developer set, boilerplates!

If you implement some icons from the set into your app or website, please let us know.

You can follow our Twitter feed at @androidicons, or contact us via mail at icons@androidicons.com if you have any questions or suggestions.

Guenther Beyer

--------------------------------------------
