--------------------------------------------
http://www.androidicons.com/
--------------------------------------------

THANK YOU for downloading the free examples of the Androidicons Developer set!

We would love to hear about the awesome projects you create with a little support from our icons. If you implement icons from the set into your app or website, please be so kind to let us know, so we can salute and applaud you.

We continuously update, perfect, and expand the set with useful items. We'll notify you via email so you can download them for free.

Androidicons is a product by Opoloo. You can follow our Twitter feed at @opoloo, our G+ site at google.com/+Opoloo, or contact us via mail at info@opoloo.com concerning any questions or suggestions.

Guenther Beyer

--------------------------------------------
